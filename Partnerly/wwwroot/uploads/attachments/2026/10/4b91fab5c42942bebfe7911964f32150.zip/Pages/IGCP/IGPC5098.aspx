<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true"
    ValidateRequest="false" CodeFile="IGPC5098.aspx.cs" Inherits="Page_IGPC5098" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>
<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Width="100%" TypeName="IGCPM.Depreciation.FixedAssets.Graph.IGPCFAAssetDisposalProcess"
        PageLoadBehavior="PopulateSavedValues" Visible="True" PrimaryView="Filter">
        <CallbackCommands>
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" Caption="Selection" CaptionAlign="Justify" TabIndex="2" DataMember="Filter">
        <Template>
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="M"></px:PXLayoutRule>
	<px:PXSelector AllowEdit="True" AutoRefresh="True" CommitChanges="True" runat="server" ID="edFilterAssetID" DataField="AssetID" ></px:PXSelector>
            <px:PXSegmentMask runat="server" ID="edFilterInventoryID" DataField="InventoryID" AutoRefresh="True" CommitChanges="True" AllowEdit="True"></px:PXSegmentMask>
	        <px:PXSelector runat="server" ID="edFilterSerialNbr" DataField="SerialNbr" AutoRefresh="True" CommitChanges="True" ></px:PXSelector>
	<px:PXLayoutRule runat="server" ID="CstPXLayoutRule2" StartColumn="True" ></px:PXLayoutRule>
	<px:PXDateTimeEdit CommitChanges="True" runat="server" ID="edDisposalDate" DataField="DisposalDate" ></px:PXDateTimeEdit></Template>
    </px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:PXGrid SyncPositionWithGraph="True" KeepPosition="True" SyncPosition="True" FastFilterFields="InventoryID" ID="grid" runat="server" Height="144px" Style="z-index: 100; left: 0px; top: 0px;" Width="100%" AdjustPageSize="Auto"
        AllowPaging="True" AllowSearch="True" BatchUpdate="True" TabIndex="100" Caption="Assets Disposal" DataSourceID="ds" SkinID="PrimaryInquire">
        <Levels>
            <px:PXGridLevel DataMember="ResultPreview">
                <Columns>
                    <px:PXGridColumn AllowNull="False" DataField="Selected" TextAlign="Center" Type="CheckBox" AllowCheckAll="True" AllowSort="False" AllowMove="False" Width="40px"></px:PXGridColumn>
                    <px:PXGridColumn DataField="Status" Width="60px" ></px:PXGridColumn>
                    <px:PXGridColumn DataField="AssetID" Width="130px" ></px:PXGridColumn>
                    <px:PXGridColumn DataField="BookID" Width="100px" ></px:PXGridColumn>
                    <px:PXGridColumn DataField="AcquisitionCost" Width="90px" ></px:PXGridColumn>
                    <px:PXGridColumn DataField="YtdDepreciated" Width="90px" ></px:PXGridColumn>
                    <px:PXGridColumn DataField="YtdBal" Width="90px" ></px:PXGridColumn>
	<px:PXGridColumn DataField="PeriodID" Width="80px" ></px:PXGridColumn>
                    <px:PXGridColumn DataField="InventoryID" Width="120px"></px:PXGridColumn>
                    <px:PXGridColumn DataField="InventoryID_InventoryItem_Descr" Width="220px"></px:PXGridColumn>
                    <px:PXGridColumn DataField="SubItemID" Width="30px"></px:PXGridColumn>
                    <px:PXGridColumn DataField="SiteID" Width="100px"></px:PXGridColumn>
                    <px:PXGridColumn DataField="LocationID" Width="100px"></px:PXGridColumn>
                    <px:PXGridColumn DataField="SerialNbr" Width="180px"></px:PXGridColumn>
                    <px:PXGridColumn DataField="QtyOnHand" Width="90px" ></px:PXGridColumn>
                    <px:PXGridColumn DataField="StatusCode" Width="90px"></px:PXGridColumn>
                    <px:PXGridColumn DataField="LineStatus" Width="70px"></px:PXGridColumn></Columns>
                <RowTemplate>
                    <px:PXSegmentMask runat="server" ID="edInventoryID" DataField="InventoryID" AllowEdit="True" ></px:PXSegmentMask>
	<px:PXSelector AllowEdit="True" runat="server" ID="edAssetID" DataField="AssetID" ></px:PXSelector></RowTemplate>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="150"></AutoSize>
        <Mode AllowAddNew="False" AllowDelete="False" AllowUpdate="False"></Mode>
    </px:PXGrid>
</asp:Content>