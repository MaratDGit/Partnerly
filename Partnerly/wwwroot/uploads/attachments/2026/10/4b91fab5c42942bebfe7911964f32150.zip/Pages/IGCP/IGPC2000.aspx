<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="IGPC2000.aspx.cs" Inherits="Page_IGPC2000" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="IGCPM.Graph.IGPCGetGeotabDataEntry"
        PrimaryView="Filter"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
	<px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="Filter" Width="100%" Height="100px" AllowAutoHide="false">
		<Template>
			<px:PXLayoutRule ControlSize="SM" LabelsWidth="SM" ID="PXLayoutRule1" runat="server" StartRow="True"></px:PXLayoutRule>
			<px:PXCheckBox AlignLeft="True" CommitChanges="True" runat="server" ID="edFaultDataID" DataField="FaultData" ></px:PXCheckBox>
			<px:PXCheckBox AlignLeft="True" CommitChanges="True" runat="server" ID="edFuelTaxDetailID" DataField="FuelTaxDetail" ></px:PXCheckBox>
			<px:PXCheckBox AlignLeft="True" CommitChanges="True" runat="server" ID="edHourlyFuelTaxDetailID" DataField="HourlyFuelTaxDetail" ></px:PXCheckBox>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule8" StartColumn="True" ></px:PXLayoutRule>
			<px:PXCheckBox AlignLeft="True" CommitChanges="True" runat="server" ID="chkDutyStatusLogID" DataField="DutyStatusLog" ></px:PXCheckBox></Template>
	</px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" Runat="Server">
	<px:PXGrid NoteIndicator="False" FilesIndicator="False" DataSourceID="ds" SkinID="Inquire" Width="100%" runat="server" ID="gridVehicleSelectedID">
		<Levels>
			<px:PXGridLevel DataMember="VehicleSelected" >
				<Columns>
					<px:PXGridColumn CommitChanges="True" Type="CheckBox" AllowCheckAll="True" TextAlign="Center" DataField="Selected" Width="60" ></px:PXGridColumn>
					<px:PXGridColumn DataField="InventoryID" Width="70" ></px:PXGridColumn>
					<px:PXGridColumn DataField="InventoryID_description" Width="280" ></px:PXGridColumn>
					<px:PXGridColumn DataField="LotSerialNbr" Width="220" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels>
		<AutoSize Container="Window" MinHeight="200" Enabled="True" ></AutoSize>
		<AutoSize MinHeight="200" ></AutoSize></px:PXGrid></asp:Content>