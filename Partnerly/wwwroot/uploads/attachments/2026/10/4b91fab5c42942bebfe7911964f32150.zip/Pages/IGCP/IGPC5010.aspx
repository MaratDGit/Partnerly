<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="IGPC5010.aspx.cs" Inherits="Page_IGPC5010" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="IGCPM.Graph.IGPC.IGPCXtellioDeviceEntry"
        PrimaryView="Device"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
	<px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="Device" Width="100%" Height="100px" AllowAutoHide="false">
		<Template>
			<px:PXLayoutRule ID="PXLayoutRule1" runat="server" StartRow="True"></px:PXLayoutRule>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule1" StartColumn="True" ColumnWidth="XM" LabelsWidth="SM" ></px:PXLayoutRule>
			<px:PXSelector CommitChanges="True" runat="server" ID="edXtellioID" DataField="XtellioID" ></px:PXSelector>
			<px:PXTextEdit runat="server" ID="edNameID" DataField="Name" ></px:PXTextEdit></Template>
	</px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" Runat="Server">
	<px:PXTab Width="100%" runat="server" ID="DeviceInfoTab">
		<Items>
			<px:PXTabItem BindingContext="form" Text="Xtellio Data" >
				<Template>
					<px:PXFormView Height="" AllowCollapse="False" DataMember="IGPCXtellioDeviceInfo" Width="100%" DataSourceID="ds" runat="server" ID="IGCPMXtellioDeviceInfoID" >
						<Template>
							<px:PXLayoutRule ControlSize="XM" LabelsWidth="SM" runat="server" ID="CstPXLayoutRule7" StartColumn="True" ></px:PXLayoutRule>
							<px:PXLayoutRule GroupCaption="Device Info" runat="server" ID="CstPXLayoutRule10" StartGroup="True" ></px:PXLayoutRule>
							<px:PXTextEdit runat="server" ID="CstPXTextEdit18" DataField="Type" ></px:PXTextEdit>
							<px:PXTextEdit runat="server" ID="CstPXTextEdit16" DataField="Mac" ></px:PXTextEdit>
							<px:PXTextEdit runat="server" ID="CstPXTextEdit14" DataField="Customer" ></px:PXTextEdit>
							<px:PXTextEdit runat="server" ID="CstPXTextEdit17" DataField="SIMProvider" ></px:PXTextEdit>
							<px:PXTextEdit runat="server" ID="CstPXTextEdit15" DataField="ICCID" ></px:PXTextEdit>
							<px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit13" DataField="CreatedAt" ></px:PXDateTimeEdit>
							<px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit19" DataField="UpdatedAt" ></px:PXDateTimeEdit>
							<px:PXLayoutRule LabelsWidth="SM" ControlSize="XM" runat="server" ID="CstPXLayoutRule8" StartColumn="True" ></px:PXLayoutRule>
							<px:PXLayoutRule GroupCaption="Device health" runat="server" ID="CstPXLayoutRule11" StartGroup="True" ></px:PXLayoutRule>
							<px:PXTextEdit runat="server" ID="CstPXTextEdit24" DataField="State" ></px:PXTextEdit>
							<px:PXTextEdit runat="server" ID="CstPXTextEdit23" DataField="Profile" ></px:PXTextEdit>
							<px:PXNumberEdit runat="server" ID="CstPXNumberEdit22" DataField="BatteryLevel" ></px:PXNumberEdit>
							<px:PXNumberEdit runat="server" ID="CstPXNumberEdit25" DataField="TotalTransmits" ></px:PXNumberEdit>
							<px:PXNumberEdit runat="server" ID="CstPXNumberEdit20" DataField="AvgGPStimetofix" ></px:PXNumberEdit>
							<px:PXNumberEdit runat="server" ID="CstPXNumberEdit21" DataField="Avgmodemontime" ></px:PXNumberEdit>
							<px:PXLayoutRule ControlSize="XM" LabelsWidth="SM" runat="server" ID="CstPXLayoutRule9" StartColumn="True" ></px:PXLayoutRule>
							<px:PXLayoutRule GroupCaption="Location (GPS)" runat="server" ID="CstPXLayoutRule12" StartGroup="True" ></px:PXLayoutRule>
							<px:PXNumberEdit runat="server" ID="CstPXNumberEdit27" DataField="Latitude" ></px:PXNumberEdit>
							<px:PXNumberEdit runat="server" ID="CstPXNumberEdit28" DataField="Longitude" ></px:PXNumberEdit>
							<px:PXNumberEdit runat="server" ID="CstPXNumberEdit26" DataField="GPStimeout" ></px:PXNumberEdit>
							<px:PXNumberEdit runat="server" ID="CstPXNumberEdit30" DataField="Timetofix" ></px:PXNumberEdit>
							<px:PXNumberEdit runat="server" ID="CstPXNumberEdit29" DataField="Satellites" ></px:PXNumberEdit></Template>
						<AutoSize Enabled="True" MinHeight="200" Container="Window" ></AutoSize>
						<AutoSize Enabled="True" ></AutoSize>
						<AutoSize MinHeight="200" ></AutoSize></px:PXFormView></Template></px:PXTabItem></Items></px:PXTab></asp:Content>