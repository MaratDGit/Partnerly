<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="IGPC5000.aspx.cs" Inherits="Page_IGPC5000" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="IGCPM.Graph.IGPC.IGPCEquipmentStatus"
        PrimaryView="FilterView"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
	<px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="FilterView" Width="100%" Height="100px" AllowAutoHide="false">
		<Template>
			<px:PXLayoutRule ID="PXLayoutRule1" runat="server" StartRow="True"></px:PXLayoutRule>
			<px:PXLayoutRule ControlSize="XM" runat="server" ID="CstPXLayoutRule1" StartColumn="True" ColumnWidth="" LabelsWidth="SM" ></px:PXLayoutRule>
			<px:PXTextEdit CommitChanges="True" runat="server" ID="edSerialNbrID" DataField="SerialNbr" ></px:PXTextEdit></Template>
	</px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" Runat="Server">
	<px:PXTab Width="100%" runat="server" ID="GeneralTab">
		<Items>
			<px:PXTabItem BindingContext="form" Text="Geotab Data" >
				<Template>
					<px:PXFormView DataSourceID="ds" Width="100%" DataMember="IGPCGeotabDeviceInfo" runat="server" ID="IGCPMGeotabDeviceInfoID" >
						<Template>
							<px:PXLayoutRule ControlSize="XM" LabelsWidth="SM" runat="server" ID="CstPXLayoutRule6" StartColumn="True" ></px:PXLayoutRule>
							<px:PXTextEdit runat="server" ID="CstPXTextEdit12" DataField="GeotabDeviceName" ></px:PXTextEdit>
							<px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit8" DataField="ActiveFrom" ></px:PXDateTimeEdit>
							<px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit9" DataField="ActiveTo" ></px:PXDateTimeEdit>
							<px:PXTextEdit runat="server" ID="CstPXTextEdit10" DataField="DriverFirstName" ></px:PXTextEdit>
							<px:PXTextEdit runat="server" ID="CstPXTextEdit11" DataField="DriverLastName" ></px:PXTextEdit>
							<px:PXLayoutRule ControlSize="XM" LabelsWidth="SM" runat="server" ID="CstPXLayoutRule7" StartColumn="True" ></px:PXLayoutRule>
							<px:PXTextEdit runat="server" ID="CstPXTextEdit13" DataField="GeotabSerialNumber" ></px:PXTextEdit>
							<px:PXTextEdit runat="server" ID="CstPXTextEdit16" DataField="VehicleIdentificationNumber" ></px:PXTextEdit>
							<px:PXNumberEdit runat="server" ID="CstPXNumberEdit14" DataField="Latitude" ></px:PXNumberEdit>
							<px:PXNumberEdit runat="server" ID="CstPXNumberEdit15" DataField="Longitude" ></px:PXNumberEdit></Template>
						<AutoSize Enabled="True" MinHeight="200" Container="Window" ></AutoSize>
						<AutoSize Enabled="True" ></AutoSize>
						<AutoSize MinHeight="200" ></AutoSize></px:PXFormView></Template></px:PXTabItem></Items></px:PXTab></asp:Content>