<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="IGPC5020.aspx.cs" Inherits="Page_IGPC5020" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="IGCPM.Graph.IGPC.IGPCEquipmentDistanceMaint"
        PrimaryView="Filter"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
	<px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="Filter" Width="100%" Height="100px" AllowAutoHide="false">
		<Template>
			<px:PXLayoutRule ID="PXLayoutRule1" runat="server" StartRow="True"></px:PXLayoutRule>
			<px:PXLayoutRule ControlSize="S" LabelsWidth="M" runat="server" ID="CstPXLayoutRule1" StartColumn="True" ></px:PXLayoutRule>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule4" Merge="True" ></px:PXLayoutRule>
			<px:PXNumberEdit CommitChanges="True" runat="server" ID="edDistanceFromWarehouseConverted" DataField="DistanceFromWarehouseConverted" ></px:PXNumberEdit>
			<px:PXDropDown SuppressLabel="True" CommitChanges="True" runat="server" ID="edDistanceUnit" DataField="DistanceUnit" ></px:PXDropDown>
			<px:PXLayoutRule runat="server" ID="CstLayoutRule8" ></px:PXLayoutRule>
			<px:PXCheckBox CommitChanges="True" runat="server" ID="chkShowOnlyWithinSelectedDistanceID" DataField="ShowOnlyWithinSelectedDistance" ></px:PXCheckBox></Template>
	</px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" Runat="Server">
	<px:PXGrid AllowFilter="True" AllowPaging="True" FilesIndicator="False" NoteIndicator="False" ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="150px" SkinID="Inquire" AllowAutoHide="false">
		<Levels>
			<px:PXGridLevel DataMember="Records">
			    <Columns>
				<px:PXGridColumn DataField="VehicleIdentificationNumber" Width="180" ></px:PXGridColumn>
				<px:PXGridColumn DataField="GeotabDeviceName" Width="280" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Longitude" Width="100" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Latitude" Width="100" ></px:PXGridColumn>
				<px:PXGridColumn DataField="DistanceUnit" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="DistanceFromWarehouseConverted" Width="100" ></px:PXGridColumn></Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
		<ActionBar >
		</ActionBar>
	</px:PXGrid>
</asp:Content>