<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="IGPC1099.aspx.cs" Inherits="Page_IGPC1099" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="IGCPM.Graph.IGPCSetupMaint"
        PrimaryView="Setup">
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
    <px:PXTab Width="100%" Height="500px" runat="server" ID="tab" DataMember="Setup">
        <Items>
            <px:PXTabItem Text="General Settings">
                <Template>
                    <px:PXLayoutRule runat="server" ID="lrIGCPMLayoutRuleRow1" StartRow="True" ></px:PXLayoutRule>
                    <px:PXLayoutRule runat="server" ID="lrIGCPMLayoutRuleCol1" StartColumn="True" ></px:PXLayoutRule>
                    <px:PXPanel RenderStyle="Fieldset" Caption="Enable Construction Project" runat="server" ID="pnlIGCPMEnableDisable">
			<px:PXLayoutRule runat="server" ID="lrIGCPMEnableDisable" StartColumn="True" ControlSize="L" LabelsWidth="M"></px:PXLayoutRule>
			<px:PXCheckBox CommitChanges="True" runat="server" ID="chkEnableConstructionProject" DataField="EnableConstructionProject" ></px:PXCheckBox></px:PXPanel>
                    <px:PXLayoutRule runat="server" ID="lrIGCPMLayoutRuleRow2" StartRow="True" ></px:PXLayoutRule>
                    <px:PXLayoutRule runat="server" ID="lrIGCPMLayoutRuleCol2" StartColumn="True" ></px:PXLayoutRule>
                    <px:PXPanel RenderStyle="Fieldset" Caption="Geotab Settings" runat="server" ID="pnlIGCPMGeotabSettings">
			<px:PXLayoutRule runat="server" ID="lrIGCPMGeotabSettings" StartColumn="True" ControlSize="L" LabelsWidth="M"></px:PXLayoutRule>
			<px:PXCheckBox CommitChanges="True" runat="server" ID="chkEnableGeotabIntegration" DataField="EnableGeotabIntegration" ></px:PXCheckBox>
			<px:PXTextEdit CommitChanges="True" runat="server" ID="edApiUrlID" DataField="ApiUrl" ></px:PXTextEdit>
			<px:PXTextEdit CommitChanges="True" runat="server" ID="edGeotabUsernameID" DataField="GeotabUsername" ></px:PXTextEdit>
			<px:PXTextEdit CommitChanges="True" runat="server" ID="edGeotabPasswordID" DataField="GeotabPassword" ></px:PXTextEdit>
			<px:PXTextEdit CommitChanges="True" runat="server" ID="edGeotabDatabaseNameID" DataField="GeotabDatabaseName" ></px:PXTextEdit>
			<px:PXLayoutRule runat="server" ID="lrIGCPMGeotabSettingsMerge1" Merge="True" ></px:PXLayoutRule>
			<px:PXNumberEdit runat="server" ID="edMaxDistanceFromWarehouse" DataField="MaxDistanceFromWarehouse" ></px:PXNumberEdit>
			<px:PXDropDown CommitChanges="True" Width="100px" SuppressLabel="True" runat="server" ID="edDistanceUnit" DataField="DistanceUnit" ></px:PXDropDown></px:PXPanel>
                    <px:PXLayoutRule ControlSize="L" LabelsWidth="M" runat="server" ID="lrIGCPMLayoutRuleCol3" StartColumn="True" ></px:PXLayoutRule>
                    <px:PXPanel RenderStyle="Fieldset" Caption="Xtellio Settings" runat="server" ID="pnlIGCPMXtellioSettings">
			<px:PXLayoutRule runat="server" ID="lrIGCPMXtellioSettings" StartColumn="True" ControlSize="L" LabelsWidth="M"></px:PXLayoutRule>
			<px:PXCheckBox CommitChanges="True" runat="server" ID="chkEnableXtellioIntegration" DataField="EnableXtellioIntegration" ></px:PXCheckBox>
			<px:PXTextEdit runat="server" ID="edApiKeyID" DataField="ApiKey" ></px:PXTextEdit></px:PXPanel>
	<px:PXLayoutRule ControlSize="XM" LabelsWidth="SM" runat="server" ID="CstPXLayoutRule22" StartColumn="True" ></px:PXLayoutRule>
	<px:PXPanel RenderStyle="Fieldset" Caption="Daily Field Report" runat="server" ID="CstPanel19" >
		<px:PXLayoutRule ControlSize="L" LabelsWidth="M" runat="server" ID="CstPXLayoutRule21" StartColumn="True" ></px:PXLayoutRule>
		<px:PXCheckBox CommitChanges="True" runat="server" ID="chkDailyFieldReportIntegration" DataField="DailyFieldReportIntegration" ></px:PXCheckBox></px:PXPanel></Template>
            </px:PXTabItem>
            <px:PXTabItem VisibleExp="DataControls[&quot;chkEnableConstructionProject&quot;].Value=1" Text="Depreciation Settings">
                <Template>
                    <px:PXLayoutRule ControlSize="XM" LabelsWidth="M" runat="server" ID="lrlIGCPMDepreciationCol1" StartColumn="True" ></px:PXLayoutRule>
                    <px:PXPanel RenderStyle="Fieldset" runat="server" ID="pnlIGCPMDepreciation1" Caption="Depreciation Settings">
			<px:PXLayoutRule runat="server" ID="lrIGCPMDepreciation1" StartColumn="True" ControlSize="XM" LabelsWidth="M"></px:PXLayoutRule>
                        <px:PXDropDown runat="server" ID="edDepreciationBy" DataField="DepreciationBy" CommitChanges="True" ></px:PXDropDown>
                        <px:PXNumberEdit runat="server" ID="edFAConversionThreshold" DataField="FAConversionThreshold" ></px:PXNumberEdit>
                    </px:PXPanel>
                </Template>
      </px:PXTabItem></Items>
      <AutoSize MinHeight="480" Enabled="True" Container="Window"></AutoSize>
      <AutoSize Enabled="True"></AutoSize>
    </px:PXTab>
</asp:Content>