import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter, PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig } from "client-controls";

@graphInfo({graphType: "IGCPM.Graph.IGPC.IGPCXtellioDeviceEntry", primaryView: "Device", })
export class IGPC5010 extends PXScreen {

	Device = createSingle(IGPCXtellioDevice);
   	@viewInfo({containerName: "Xtellio Data"})
	IGPCXtellioDeviceInfo = createSingle(IGPCXtellioDevice2);
}// Views

export class IGPCXtellioDevice extends PXView  {

	XtellioID : PXFieldState<PXFieldOptions.CommitChanges>;
	Name : PXFieldState;
}

export class IGPCXtellioDevice2 extends PXView  {

	Type : PXFieldState;
	Mac : PXFieldState;
	Customer : PXFieldState;
	SIMProvider : PXFieldState;
	ICCID : PXFieldState;
	CreatedAt : PXFieldState;
	UpdatedAt : PXFieldState;
	State : PXFieldState;
	Profile : PXFieldState;
	BatteryLevel : PXFieldState;
	TotalTransmits : PXFieldState;
	AvgGPStimetofix : PXFieldState;
	Avgmodemontime : PXFieldState;
	Latitude : PXFieldState;
	Longitude : PXFieldState;
	GPStimeout : PXFieldState;
	Timetofix : PXFieldState;
	Satellites : PXFieldState;
}