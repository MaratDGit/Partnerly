import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter, PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility } from "client-controls";

@graphInfo({graphType: "IGCPM.Depreciation.FixedAssets.Graph.IGPCFAAssetConversionProcess", primaryView: "Filter", pageLoadBehavior: PXPageLoadBehavior.PopulateSavedValues})
export class IGPC5099 extends PXScreen {

   	@viewInfo({containerName: "Selection"})
	Filter = createSingle(IGPCFAAssetConversionFilter);
   	@viewInfo({containerName: "Rental Cost Adjustment & Asset Conversion"})
	ResultPreview = createCollection(IGPCFAAssetConversion);
}// Views

export class IGPCFAAssetConversionFilter extends PXView  {

	@controlConfig({allowEdit:true})
	InventoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	SerialNbr : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	allowDelete: false,
	allowInsert: false,
	fastFilterByAllFields: false,
	showFastFilter: GridFastFilterVisibility.ToolBar,
	mergeToolbarWith: "ScreenToolbar",
	preset: GridPreset.Inquiry
})
export class IGPCFAAssetConversion extends PXView  {

	@columnConfig({allowSort: false, allowNull: false, width: 30, textAlign: TextAlign.Center, type: GridColumnType.CheckBox, allowCheckAll: true })	Selected : PXFieldState;
	@columnConfig({hideViewLink: true, width: 120, allowFastFilter: true})	InventoryID : PXFieldState;
	@columnConfig({width: 220})	InventoryID_InventoryItem_Descr : PXFieldState;
	@columnConfig({width: 30})	SubItemID : PXFieldState;
	@columnConfig({width: 108})	SiteID : PXFieldState;
	@columnConfig({width: 100})	LocationID : PXFieldState;
	@columnConfig({width: 220})	SerialNbr : PXFieldState;
	@columnConfig({width: 90})	StatusCode : PXFieldState;
	@columnConfig({width: 70})	LineStatus : PXFieldState;
	@columnConfig({width: 100})	UnitCost : PXFieldState;
}