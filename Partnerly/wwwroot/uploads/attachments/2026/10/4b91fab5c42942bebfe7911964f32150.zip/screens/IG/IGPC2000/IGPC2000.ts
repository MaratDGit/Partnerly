import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter, PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility } from "client-controls";

@graphInfo({graphType: "IGCPM.Graph.IGPCGetGeotabDataEntry", primaryView: "Filter", })
export class IGPC2000 extends PXScreen {

	Filter = createSingle(IGPCGetGeotabDataFilter);
	VehicleSelected = createCollection(INLotSerialStatus);
}// Views

export class IGPCGetGeotabDataFilter extends PXView  {

	FaultData : PXFieldState<PXFieldOptions.CommitChanges>;
	FuelTaxDetail : PXFieldState<PXFieldOptions.CommitChanges>;
	HourlyFuelTaxDetail : PXFieldState<PXFieldOptions.CommitChanges>;
	DutyStatusLog : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class INLotSerialStatus extends PXView  {

	@columnConfig({width: 60, textAlign: TextAlign.Center, type: GridColumnType.CheckBox, allowCheckAll: true})	Selected : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 70})	InventoryID : PXFieldState;
	@columnConfig({width: 280})	InventoryID_description : PXFieldState;
	@columnConfig({width: 220})	LotSerialNbr : PXFieldState;
}