import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter, PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig } from "client-controls";

@graphInfo({graphType: "IGCPM.Graph.IGPCSetupMaint", primaryView: "Setup", })
export class IGPC1099 extends PXScreen {

	Setup = createSingle(IGPCSetup);
}// Views

export class IGPCSetup extends PXView  {

	EnableConstructionProject : PXFieldState<PXFieldOptions.CommitChanges>;
	EnableGeotabIntegration : PXFieldState<PXFieldOptions.CommitChanges>;
	ApiUrl : PXFieldState<PXFieldOptions.CommitChanges>;
	GeotabUsername : PXFieldState<PXFieldOptions.CommitChanges>;
	GeotabPassword : PXFieldState<PXFieldOptions.CommitChanges>;
	GeotabDatabaseName : PXFieldState<PXFieldOptions.CommitChanges>;
	MaxDistanceFromWarehouse : PXFieldState;
	DistanceUnit : PXFieldState<PXFieldOptions.CommitChanges>;
	EnableXtellioIntegration : PXFieldState<PXFieldOptions.CommitChanges>;
	ApiKey : PXFieldState;
	DailyFieldReportIntegration : PXFieldState<PXFieldOptions.CommitChanges>;
	DepreciationBy : PXFieldState<PXFieldOptions.CommitChanges>;
	FAConversionThreshold : PXFieldState;
}