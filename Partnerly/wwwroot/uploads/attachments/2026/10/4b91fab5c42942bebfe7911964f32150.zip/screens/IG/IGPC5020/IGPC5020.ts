import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter, PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig } from "client-controls";

@graphInfo({graphType: "IGCPM.Graph.IGPC.IGPCEquipmentDistanceMaint", primaryView: "Filter", })
export class IGPC5020 extends PXScreen {

	Filter = createSingle(IGPCEquipmentDistanceFilter);
	Records = createCollection(IGPCDeviceInfo);
}// Views

export class IGPCEquipmentDistanceFilter extends PXView  {

	DistanceFromWarehouseConverted : PXFieldState<PXFieldOptions.CommitChanges>;
	DistanceUnit : PXFieldState<PXFieldOptions.CommitChanges>;
	ShowOnlyWithinSelectedDistance : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class IGPCDeviceInfo extends PXView  {

	@columnConfig({width: 180})	VehicleIdentificationNumber : PXFieldState;
	@columnConfig({width: 280})	GeotabDeviceName : PXFieldState;
	@columnConfig({width: 100})	Longitude : PXFieldState;
	@columnConfig({width: 100})	Latitude : PXFieldState;
	@columnConfig({width: 70})	DistanceUnit : PXFieldState;
	@columnConfig({width: 100})	DistanceFromWarehouseConverted : PXFieldState;
}