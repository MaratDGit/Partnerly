import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter, PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig } from "client-controls";

@graphInfo({graphType: "IGCPM.Graph.IGPC.IGPCEquipmentStatus", primaryView: "FilterView", })
export class IGPC5000 extends PXScreen {

	FilterView = createSingle(IGPCEquipmentStatusFilter);
   	@viewInfo({containerName: "Geotab Data"})
	IGPCGeotabDeviceInfo = createSingle(IGPCDeviceInfo);
}// Views

export class IGPCEquipmentStatusFilter extends PXView  {

	SerialNbr : PXFieldState<PXFieldOptions.CommitChanges>;
}

export class IGPCDeviceInfo extends PXView  {

	GeotabDeviceName : PXFieldState;
	ActiveFrom : PXFieldState;
	ActiveTo : PXFieldState;
	DriverFirstName : PXFieldState;
	DriverLastName : PXFieldState;
	GeotabSerialNumber : PXFieldState;
	VehicleIdentificationNumber : PXFieldState;
	Latitude : PXFieldState;
	Longitude : PXFieldState;
}