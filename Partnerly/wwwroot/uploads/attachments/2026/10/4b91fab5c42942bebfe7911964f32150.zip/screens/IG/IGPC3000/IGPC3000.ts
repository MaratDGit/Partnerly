import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter, PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility } from "client-controls";

@graphInfo({graphType: "IGCPM.Graph.IGPCXtellioDataProcess", primaryView: "DeviceSelected", })
export class IGPC3000 extends PXScreen {

	DeviceSelected = createCollection(IGPCXtellioDevice);
}// Views

@gridConfig({
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class IGPCXtellioDevice extends PXView  {

	@columnConfig({width: 60, textAlign: TextAlign.Center, type: GridColumnType.CheckBox, allowCheckAll: true})	Selected : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	XtellioID : PXFieldState;
	@columnConfig({width: 220})	Name : PXFieldState;
}