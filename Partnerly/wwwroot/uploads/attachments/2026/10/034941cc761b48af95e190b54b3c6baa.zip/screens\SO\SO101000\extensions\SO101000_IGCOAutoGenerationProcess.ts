import {
	PXFieldState,
} from "client-controls";

import {
    sosetup
} from "src/screens/SO/SO101000/SO101000"

export interface sosetup_IGCOAutoGenerationProcess extends sosetup{}
export class sosetup_IGCOAutoGenerationProcess {
   	UsrIGCOAutoPOReturn : PXFieldState;
	UsrIGCOAutoBilling : PXFieldState;
}