import {
    PXFieldState,
} from "client-controls";

import {
    DiscountSequence
} from "src/screens/AR/AR209500/AR209500"

export interface DiscountSequence_IGCODiscountSequence extends DiscountSequence{}
export class DiscountSequence_IGCODiscountSequence {
    UsrIGCOIsConsignmentDiscount : PXFieldState;
}