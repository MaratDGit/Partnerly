import {
    PXFieldState,
    PXFieldOptions
} from "client-controls";

import {
    SO301000,
    SOOrderHeader
} from "src/screens/SO/SO301000/SO301000"

export interface SO301000_IGCODiscountSequence extends SO301000 {}
export class SO301000_IGCODiscountSequence {}

export interface SOOrderHeader_IGCOSOOrder extends SOOrderHeader{}
export class SOOrderHeader_IGCOSOOrder {
    UsrIGCOCuryVatExemptTotal : PXFieldState<PXFieldOptions.Disabled>;
    UsrIGCOCuryVatTaxableTotal : PXFieldState<PXFieldOptions.Disabled>;
    UsrIGCOTaxTotal :PXFieldState<PXFieldOptions.Disabled>;
    UsrIGCOLinesTotalInclTax : PXFieldState<PXFieldOptions.Disabled>;
    CuryPremiumFreightAmt : PXFieldState<PXFieldOptions.Disabled>;
    UsrIGCOPremiumFreightTax : PXFieldState<PXFieldOptions.Disabled>;
    UsrIGCOOrderTotal : PXFieldState<PXFieldOptions.Disabled>;
}