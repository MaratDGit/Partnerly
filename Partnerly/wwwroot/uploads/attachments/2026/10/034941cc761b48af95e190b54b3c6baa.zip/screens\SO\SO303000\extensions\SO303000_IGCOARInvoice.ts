import {
    PXFieldState,
    PXFieldOptions
} from "client-controls";

import {
    SO303000,
    ARInvoice
} from "src/screens/SO/SO303000/SO303000";

export interface SO303000_IGCOARInvoice extends SO303000 {}
export class SO303000_IGCOARInvoice {}

export interface ARInvoice_IGCOARInvoice extends ARInvoice{}
export class ARInvoice_IGCOARInvoice {
    UsrIGCOConsignmentType : PXFieldState<PXFieldOptions.Disabled>;
}