import { 
    PXFieldState, 
     PXFieldOptions
} from "client-controls";

import {
    Customer2
} from "src/screens/AR/AR303000/AR303000";

import {
    Address
} from "src/screens/common/form-address/form-address"

export interface Address_IGCOCustomer extends Address{}
export class Address_IGCOCustomer {
    UsrIGCOWarehouse: PXFieldState<PXFieldOptions.CommitChanges>;
}

export interface Customer2_IGCOCustomer extends Customer2{}
export class Customer2_IGCOCustomer {
    UsrIGCONumberOfDays: PXFieldState<PXFieldOptions.CommitChanges>;
}