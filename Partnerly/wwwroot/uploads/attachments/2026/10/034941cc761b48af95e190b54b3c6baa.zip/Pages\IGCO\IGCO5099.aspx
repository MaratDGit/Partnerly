<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="IGCO5099.aspx.cs" Inherits="Page_IGCO5099" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
  <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="IGCO.IGCOCustomerConsignmentMaint"
        PrimaryView="Customer"
        >
  
    <CallbackCommands >
        <px:PXDSCallbackCommand CommitChanges="True" Name="Allocations" Visible="False" ></px:PXDSCallbackCommand></CallbackCommands></px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
  <px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="Customer" Width="100%" Height="150" AllowAutoHide="false">
    <Template>
      <px:PXLayoutRule ID="PXLayoutRule1" runat="server" StartRow="True"></px:PXLayoutRule>
      <px:PXLayoutRule runat="server" ID="CstPXLayoutRule1" StartColumn="True" ></px:PXLayoutRule>
      <px:PXSelector AllowEdit="True" CommitChanges="True" runat="server" ID="edCustomerID" DataField="CustomerID" ></px:PXSelector>
	<px:PXSegmentMask AllowEdit="True" AutoRefresh="True" CommitChanges="True" runat="server" ID="edCustomerLocationID" DataField="CustomerLocationID" ></px:PXSegmentMask>
      <px:PXSelector AllowEdit="True" CommitChanges="True" runat="server" ID="edInventoryHeaderID" DataField="InventoryID" ></px:PXSelector>
	<px:PXNumberEdit LabelWidth="" Width="" Size="" CommitChanges="True" runat="server" ID="DaysNumberPXNumberEdit" DataField="DaysNumber" >
		<AutoCallBack Command="Refresh" ></AutoCallBack></px:PXNumberEdit>
      <px:PXLayoutRule runat="server" ID="CstPXLayoutRule2" StartColumn="True" ></px:PXLayoutRule>
      <px:PXCheckBox CommitChanges="True" runat="server" ID="chkGenerateLine" DataField="GeneralLine" ></px:PXCheckBox>
	<px:PXCheckBox CommitChanges="True" runat="server" ID="chkOnlyNotAllocated" DataField="OnlyNotAllocated" ></px:PXCheckBox>
	<px:PXCheckBox CommitChanges="True" runat="server" ID="chkConsignmentDue" DataField="ConsignmentDue" ></px:PXCheckBox>
	<px:PXLayoutRule runat="server" ID="CstPXLayoutRule4" StartColumn="True" ></px:PXLayoutRule></Template>
  </px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" Runat="Server">
  <px:PXGrid AdjustPageSize="Auto" AllowPaging="True" SyncPosition="True" AutoAdjustColumns="True" ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="Details" >
    <Levels>
      <px:PXGridLevel DataMember="CustomerConsignment">
          <Columns>
	<px:PXGridColumn CommitChanges="True" AllowMove="False" AllowSort="False" TextAlign="Center" ValueField="" Type="CheckBox" AllowCheckAll="True" DataField="Selected" Width="30px" ></px:PXGridColumn>
	<px:PXGridColumn DataField="NotAllocated" Width="70" ></px:PXGridColumn>
        <px:PXGridColumn DataField="CustomerID" Width="120" ></px:PXGridColumn>
	<px:PXGridColumn DataField="CustomerLocationID" Width="70" ></px:PXGridColumn>
	<px:PXGridColumn DataField="VendorID" Width="140" CommitChanges="True" />
        <px:PXGridColumn DataField="ShipmentNbr" Width="70" ></px:PXGridColumn>
        <px:PXGridColumn DataField="InventoryID" Width="100" ></px:PXGridColumn>
        <px:PXGridColumn DataField="TransferNbr" Width="70" ></px:PXGridColumn>
        <px:PXGridColumn DataField="RefNbr" Width="70" ></px:PXGridColumn>
        <px:PXGridColumn DataField="LineNbr" Width="70" ></px:PXGridColumn>
	<px:PXGridColumn CommitChanges="True" DataField="QtySelected" Width="100" ></px:PXGridColumn>
	<px:PXGridColumn DataField="QtyAvail" Width="100" ></px:PXGridColumn>
        <px:PXGridColumn DataField="QtyConsigned" Width="100" ></px:PXGridColumn>
        <px:PXGridColumn DataField="Qtybn" Width="100" ></px:PXGridColumn>
        <px:PXGridColumn DataField="Qtyvr" Width="100" ></px:PXGridColumn>
        <px:PXGridColumn DataField="QtyRemained" Width="100" ></px:PXGridColumn>
        <px:PXGridColumn DataField="Price" Width="100" ></px:PXGridColumn>
        <px:PXGridColumn DataField="RemainedAmount" Width="100" ></px:PXGridColumn></Columns>
      </px:PXGridLevel>
    </Levels>
    <AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>


  
    <ActionBar>
      <CustomItems>
        <px:PXToolBarButton Key="cmdLS" CommandSourceID="ds" CommandName="Allocations" DependOnGrid="grid" Text="Allocations" >
          <AutoCallBack Target="ds" Enabled="True" Command="Allocations" ></AutoCallBack></px:PXToolBarButton></CustomItems>
	<Actions>
		<AddNew MenuVisible="False" ></AddNew>
		<Delete MenuVisible="False" ></Delete>
		<Delete ToolBarVisible="False" ></Delete></Actions>
	<Actions>
		<AddNew ToolBarVisible="False" ></AddNew></Actions></ActionBar></px:PXGrid>
  <px:PXSmartPanel LoadOnDemand="True" Position="CenterWindow" CallBackMode-CommitChanges="True" AutoReload="True" AutoCallBack-Behavior-CommitChanges="True"  CommandSourceID="ds" Key="Consignment" runat="server" ID="CstSmartPanel6" CaptionVisible="True" Caption="Allocations" Width="680px" >
    <px:PXGrid KeepPosition="True" AutoRepaint="True" SyncPosition="True" SkinID="Inquire" DataSourceID="ds" AutoAdjustColumns="True" Width="100%" Height="192px" AllowPaging="True" runat="server" ID="grid2">
      <Levels>
        <px:PXGridLevel DataMember="splits" >
          <Columns>
                                        <px:PXGridColumn DataField="InventoryID" Width="100px"  ></px:PXGridColumn>
            <px:PXGridColumn DataField="LocationID" Width="120" ></px:PXGridColumn>
            <px:PXGridColumn DataField="LotSerialNbr" Width="200" ></px:PXGridColumn>
	<px:PXGridColumn DataField="QtySelected" Width="100" ></px:PXGridColumn>
	<px:PXGridColumn DataField="QtyAvail" Width="100" ></px:PXGridColumn>
	<px:PXGridColumn DataField="QtyRemained" Width="100" ></px:PXGridColumn>
            <px:PXGridColumn DataField="Uom" Width="70" ></px:PXGridColumn>
            <px:PXGridColumn DataField="ExpireDate" Width="90" ></px:PXGridColumn></Columns>
          <RowTemplate>
            <px:PXSegmentMask AutoRefresh="True" DataSourceID="ds" runat="server" ID="CstPXSegmentMask13" DataField="InventoryID" ></px:PXSegmentMask>
            <px:PXSegmentMask AutoRefresh="True" runat="server" ID="CstPXSegmentMask14" DataField="LocationID" ></px:PXSegmentMask>
            <px:PXTextEdit runat="server" ID="CstPXTextEdit15" DataField="LotSerialNbr" ></px:PXTextEdit></RowTemplate></px:PXGridLevel></Levels>
          
          <CallbackCommands>
            <Refresh CommitChanges="True" ></Refresh></CallbackCommands>
          <AutoCallBack>
            <Behavior CommitChanges="True" ></Behavior></AutoCallBack>
          <OnChangeCommand>
            <Behavior CommitChanges="True" ></Behavior></OnChangeCommand>
	<ActionBar ActionsVisible="False" ></ActionBar></px:PXGrid>
    
    <px:PXPanel SkinID="Buttons" runat="server" ID="CstPanel8">
      <px:PXButton runat="server" ID="CstButton9" DialogResult="OK" Text="OK" ></px:PXButton></px:PXPanel></px:PXSmartPanel></asp:Content>