import {
	columnConfig,
	controlConfig,
	createCollection, createSingle,
	graphInfo,
	GridColumnType,
	gridConfig,
	GridFastFilterVisibility,
	GridPreset,
	PXActionState,
	PXFieldOptions,
	PXFieldState,
	PXScreen,
	PXView,
	TextAlign,
	viewInfo
} from "client-controls";

@graphInfo({
	graphType: "IGCO.IGCOCustomerConsignmentMaint", 
	primaryView: "Customer", 
})
export class IGCO5099 extends PXScreen {
	Customer = createSingle(IGCOCustomerFilter);
	CustomerConsignment = createCollection(IGCOCustomerConsignment);
   	@viewInfo({containerName: "splits"})
	splits = createCollection(IGCOCustomerConsignmentSplit);
}

export class IGCOCustomerFilter extends PXView  {
	@controlConfig({allowEdit:true})
	CustomerID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	CustomerLocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	InventoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	DaysNumber : PXFieldState<PXFieldOptions.CommitChanges>;
	GeneralLine : PXFieldState<PXFieldOptions.CommitChanges>;
	OnlyNotAllocated : PXFieldState<PXFieldOptions.CommitChanges>;
	ConsignmentDue : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly,
	topBarItems: {
	Allocations: {index: 0, config: {commandName: "Allocations", text: "Allocations"}},
}
})
export class IGCOCustomerConsignment extends PXView  {
	Allocations : PXActionState;

	@columnConfig({allowSort: false, width: 30, textAlign: TextAlign.Center, type: GridColumnType.CheckBox})	Selected : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 70})	NotAllocated : PXFieldState;
	@columnConfig({width: 120})	CustomerID : PXFieldState;
	@columnConfig({width: 70})	CustomerLocationID : PXFieldState;
	@columnConfig({width: 140})	VendorID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 70})	ShipmentNbr : PXFieldState;
	@columnConfig({width: 100})	InventoryID : PXFieldState;
	@columnConfig({width: 70})	TransferNbr : PXFieldState;
	@columnConfig({width: 70})	RefNbr : PXFieldState;
	@columnConfig({width: 70})	LineNbr : PXFieldState;
	@columnConfig({width: 100})	QtySelected : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	QtyAvail : PXFieldState;
	@columnConfig({width: 100})	QtyConsigned : PXFieldState;
	@columnConfig({width: 100})	Qtybn : PXFieldState;
	@columnConfig({width: 100})	Qtyvr : PXFieldState;
	@columnConfig({width: 100})	QtyRemained : PXFieldState;
	@columnConfig({width: 100})	Price : PXFieldState;
	@columnConfig({width: 100})	RemainedAmount : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class IGCOCustomerConsignmentSplit extends PXView  {
	@columnConfig({hideViewLink: true, width: 100})	InventoryID : PXFieldState;
	@columnConfig({hideViewLink: true, width: 120})	LocationID : PXFieldState;
	@columnConfig({width: 200})	LotSerialNbr : PXFieldState;
	@columnConfig({width: 100})	QtySelected : PXFieldState;
	@columnConfig({width: 100})	QtyAvail : PXFieldState;
	@columnConfig({width: 100})	QtyRemained : PXFieldState;
	@columnConfig({width: 70})	Uom : PXFieldState;
	@columnConfig({width: 90})	ExpireDate : PXFieldState;
}