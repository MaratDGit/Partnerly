import {
    PXFieldState,
    PXFieldOptions
} from "client-controls";

import {
    SOOrderTypeHeaderSettings
} from "src/screens/SO/SO201000/SO201000"

export interface SOOrderTypeHeaderSettings_IGCOSOOrderType extends SOOrderTypeHeaderSettings{}
export class SOOrderTypeHeaderSettings_IGCOSOOrderType {
    UsrIGCOUseConsignmentAcctFrom : PXFieldState<PXFieldOptions.CommitChanges>;
    UsrIGCOAcctID : PXFieldState;
    UsrIGCOSubID : PXFieldState;
}