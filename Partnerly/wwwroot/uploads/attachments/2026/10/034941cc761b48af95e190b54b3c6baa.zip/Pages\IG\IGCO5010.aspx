<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="IGCO5010.aspx.cs" Inherits="Page_IGCO5010" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="IGCO.IGCOBillingNotationProcessing"
        PrimaryView="CustomerConsignment"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
	<px:PXGrid ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="150px" SkinID="Primary" AllowAutoHide="false">
		<Levels>
			<px:PXGridLevel DataMember="CustomerConsignment">
			    <Columns>
				<px:PXGridColumn CommitChanges="True" TextAlign="Center" AllowCheckAll="True" Type="CheckBox" DataField="Selected" Width="60" ></px:PXGridColumn>
				<px:PXGridColumn DataField="InventoryID" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="VendorID" Width="140" ></px:PXGridColumn>
				<px:PXGridColumn DataField="CustomerID" Width="140" ></px:PXGridColumn>
				<px:PXGridColumn DataField="CustomerLocationID" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Price" Width="100" ></px:PXGridColumn>
				<px:PXGridColumn DataField="QtyAvail" Width="100" ></px:PXGridColumn>
				<px:PXGridColumn DataField="QtyConsigned" Width="100" ></px:PXGridColumn>
				<px:PXGridColumn DataField="QtyRemained" Width="100" ></px:PXGridColumn>
				<px:PXGridColumn LinkCommand="ViewTransfers" DataField="TransferNbr" Width="140" ></px:PXGridColumn>
				<px:PXGridColumn CommitChanges="True" LinkCommand="ViewInvoices" DataField="RefNbr" Width="140" ></px:PXGridColumn></Columns>
			        <RowTemplate>
                                      <px:PXSegmentMask AllowEdit="True" runat="server" ID="edInventoryId" DataField="InventoryID" ></px:PXSegmentMask>
                                        <px:PXSegmentMask runat="server" ID="CstPXSegmentMask2" DataField="LocationID" ></px:PXSegmentMask>
                                        <px:PXSegmentMask AllowEdit="True" runat="server" ID="edCustomerID" DataField="CustomerID" ></px:PXSegmentMask>
                                        <px:PXSegmentMask AllowEdit="True" runat="server" ID="edVendorID" DataField="VendorID" ></px:PXSegmentMask></RowTemplate></px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" />
		<ActionBar >
		</ActionBar>
	</px:PXGrid>
</asp:Content>