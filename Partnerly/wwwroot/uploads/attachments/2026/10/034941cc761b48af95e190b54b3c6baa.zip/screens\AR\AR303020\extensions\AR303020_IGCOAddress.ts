import { 
    PXFieldState, 
     PXFieldOptions
} from "client-controls";

import {
    Location2,
} from "src/screens/AR/AR303020/AR303020";

import { 
    Address 
} from "src/screens/common/form-address/form-address";

export interface Address_IGCOCustomer extends Address{}
export class Address_IGCOCustomer {
    UsrIGCOWarehouse: PXFieldState<PXFieldOptions.CommitChanges>;
    UsrIGCOLocationID: PXFieldState<PXFieldOptions.CommitChanges>;
}

export interface Location2_IGCOCustomer extends Location2{}
export class Location2_IGCOCustomer {
    UsrIGCOTermsID: PXFieldState<PXFieldOptions.CommitChanges>;
}