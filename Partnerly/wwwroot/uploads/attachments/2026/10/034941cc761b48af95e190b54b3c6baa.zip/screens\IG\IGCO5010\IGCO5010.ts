import {
	columnConfig,
	createCollection,
	graphInfo,
	GridColumnType,
	gridConfig,
	GridFastFilterVisibility,
	GridPreset,
	linkCommand,
	PXFieldOptions,
	PXFieldState,
	PXScreen,
	PXView,
	TextAlign
} from "client-controls";

@graphInfo({
	graphType: "IGCO.IGCOBillingNotationProcessing", 
	primaryView: "CustomerConsignment", 
})
export class IGCO5010 extends PXScreen {
	CustomerConsignment = createCollection(IGCOCustomerConsignment);
}

@gridConfig({
	showFastFilter: GridFastFilterVisibility.False,
	mergeToolbarWith: "ScreenToolbar",
	preset: GridPreset.Primary
})
export class IGCOCustomerConsignment extends PXView  {
	@columnConfig({width: 60, textAlign: TextAlign.Center, type: GridColumnType.CheckBox})	Selected : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({hideViewLink: true, width: 70})	InventoryID : PXFieldState;
	@columnConfig({hideViewLink: true, width: 140})	VendorID : PXFieldState;
	@columnConfig({hideViewLink: true, width: 140})	CustomerID : PXFieldState;
	@columnConfig({width: 70})	CustomerLocationID : PXFieldState;
	@columnConfig({width: 100})	Price : PXFieldState;
	@columnConfig({width: 100})	QtyAvail : PXFieldState;
	@columnConfig({width: 100})	QtyConsigned : PXFieldState;
	@columnConfig({width: 100})	QtyRemained : PXFieldState;
	@linkCommand("ViewTransfers")
	@columnConfig({width: 140})	TransferNbr : PXFieldState;
	@linkCommand("ViewInvoices")
	@columnConfig({width: 140})	RefNbr : PXFieldState<PXFieldOptions.CommitChanges>;
	//LocationID : PXFieldState;
}